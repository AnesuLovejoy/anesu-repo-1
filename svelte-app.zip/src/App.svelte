<link rel="stylesheet" href="https://unpkg.com/onsenui/css/onsenui.css">
<link rel="stylesheet" href="https://unpkg.com/onsenui/css/onsen-css-components.min.css">
<script src="https://unpkg.com/onsenui/js/onsenui.min.js"></script>
<div class="toolbar toolbar--material">
  <div class="toolbar__left toolbar--material__left">
 </div>
  <div class="toolbar__center toolbar--material__center">
    Liquify
  </div>
  <div class="toolbar__right toolbar--material__right">
    <span class="toolbar-button toolbar-button--material">
      <i class="zmdi zmdi-search"></i>
    </span>
    <span class="toolbar-button toolbar-button--material">
      <i class="zmdi zmdi-favorite"></i>
    </span>
    <span class="toolbar-button toolbar-button--material">
      <i class="zmdi zmdi-more-vert"></i>
    </span>
  </div>
</div>
<div class="tabbar tabbar--top tabbar--material">
  <label class="tabbar__item tabbar--material__item">
    <input type="radio" name="tabbar-material-b" checked="checked">
    <button class="tabbar__button tabbar--material__button">
      <i class="tabbar__icon tabbar--material__icon zmdi zmdi-phone"></i>
    </button>
  </label>

  <label class="tabbar__item tabbar--material__item">
    <input type="radio" name="tabbar-material-b">
    <button class="tabbar__button tabbar--material__button">
      <i class="tabbar__icon tabbar--material__icon zmdi zmdi-favorite"></i>
    </button>
  </label>

  <label class="tabbar__item tabbar--material__item">
    <input type="radio" name="tabbar-material-b">
    <button class="tabbar__button tabbar--material__button">
      <i class="tabbar__icon tabbar--material__icon zmdi zmdi-pin-account"></i>
    </button>
  </label>
</div>
<br>
<button class="button--large--cta" style="width: 95%; margin: 0 auto;">Button</button>